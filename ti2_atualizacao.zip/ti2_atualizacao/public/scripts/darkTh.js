const cbx = document.getElementById('cbx');

cbx.addEventListener('change', () => {
	document.body.classList.toggle('dark');
});