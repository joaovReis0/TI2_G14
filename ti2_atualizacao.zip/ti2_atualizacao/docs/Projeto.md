# Informações do Projeto

`ESCOLHA PROFISSIONAL - PROFISSA`

Trabalho Interdisciplinar - Aplicacões Web

`CIÊNCIAS DA COMPUTAÇÃO`

`1° SEMESTRE`

## Participantes

Os membros do grupo são:

- Artur Kazuo Peixoto Guimarães Fuzikawa
- Gabriel Terra Álvares da Silva
- João Pedro Barroso da Silva Neto
- João Vitor Reis Vilela de Castro
- Lucas Aquino dos Santos
- Lucas Vinícius dos Santos Gonçalves Coelho
- Rodrigo Paiva Fentanes

# Estrutura do Documento

1. [Contexto](1-Contexto.md)
2. [Especificações do Projeto](2-Especificação.md)
3. [Projeto da Interface](3-Interface.md)
4. [Gestão de Configuração](4-Gestão-Configuração.md)
5. [Gerenciamento de Projeto](5-Gerenciamento-Projeto.md)
6. [Implementação](6-Implementação.md)
7. [Testes e Avaliação](7-Testes.md)
8. [Referências](8-Referências.md)
9. [Apresentação](9-Apresentação.md)
